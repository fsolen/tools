# NetBox Ansible Playbook (Redis Auto-Detect)

This version automatically detects Redis master via Sentinel.
Manual `redis_master` definition is no longer required.

- Sentinel quorum: 2
- Redis password via Vault (kv/data/netbox/redis password)
- Cluster auto-healing & dynamic reconfiguration
