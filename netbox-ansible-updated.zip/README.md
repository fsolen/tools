NetBox HA Ansible project (Debian 12) - Updated

Includes:
- Vault AppRole integration (fetches DB and S3 secrets)
- Redis Sentinel running on the same NetBox hosts (configurable)
- Patroni failover/test play (tagged 'patroni-test')
- NetScaler healthcheck example config

Usage:
1. Fill group_vars/all.yml with your values (Vault role_id & secret_id). You can store those in Ansible Vault.
2. Run: ansible-playbook site.yml -i inventory.ini --ask-become-pass

Notes:
- The playbook will authenticate to Vault using AppRole (role_id + secret_id) and fetch secret paths:
  secret/data/netbox/db and secret/data/purefb (adjust if your Vault paths differ).
- Redis Sentinel topology: by default the first host in inventory becomes the Redis master; change `redis_master` in group_vars if needed.