path "secret/data/netbox" {
  capabilities = ["read", "list"]
}

path "secret/data/purefb" {
  capabilities = ["read", "list"]
}