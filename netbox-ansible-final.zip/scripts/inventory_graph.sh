#!/bin/bash
# Generates an inventory graph (requires ansible-inventory)
ansible-inventory -i inventory.ini --graph | tee inventory-graph.txt
echo "Saved to inventory-graph.txt"
