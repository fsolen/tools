NetBox HA Ansible project (Final)
---------------------------------

This package deploys NetBox HA on Debian 12 with:
- 6 NetBox app nodes (inetbox01/02, anetbox01/02, gnetbox01/02)
- Redis Sentinel on the same NetBox hosts (auto master detection)
- Patroni PostgreSQL cluster (external) at pgcom01.fatihsolen.com
- PureStorage FlashBlade S3 (credentials from Vault)
- HashiCorp Vault AppRole authentication (vault.fatihsolen.com)
- NetScaler healthcheck example config
- Patroni and Redis test plays (tagged)

Important playbooks / commands:
- Run full deploy: ansible-playbook site.yml -i inventory.ini --ask-become-pass
- Redis tests: ansible-playbook site.yml -i inventory.ini --tags redis-test
- Patroni tests: ansible-playbook site.yml -i inventory.ini --tags patroni-test
- Inventory topology graph: scripts/inventory_graph.sh (runs ansible-inventory --graph)

Vault behavior:
- Uses AppRole (role_id + secret_id). Provide these via Ansible Vault or `--extra-vars`.
- Vault HTTP calls include simple retry/backoff using Ansible `until`, `retries`, `delay`.

Notes:
- This is a starting production-ready skeleton. Review secrets handling and test in lab before production.
