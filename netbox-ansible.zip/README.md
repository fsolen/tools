NetBox HA Ansible project (Debian 12)
------------------------------------

This project deploys NetBox in HA mode with:
- 6 NetBox web nodes (inetbox01/02, anetbox01/02, gnetbox01/02)
- Local Redis per NetBox node (or cluster on same hosts)
- Patroni PostgreSQL cluster (external) reachable at pgcom01.fatihsolen.com
- PureStorage FlashBlade S3 endpoint at purefb01.fatihsolen.com
- HashiCorp Vault for secrets management

How to use:
1. Edit group_vars/all.yml and fill in Vault addresses / secrets paths.
2. Ensure Vault tokens/approach is configured (this playbook uses hashicorp vault lookup examples).
3. Run: ansible-playbook site.yml -i inventory.ini --ask-become-pass