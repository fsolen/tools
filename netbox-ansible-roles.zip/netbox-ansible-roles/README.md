NetBox Ansible roles (Debian 12) — External Patroni PostgreSQL, NFS media, local Redis, HTTPS (combined PEM)

Structure:
- site.yml                # main playbook
- inventory.ini           # example inventory
- group_vars/all.yml      # variables (use ansible-vault for secrets)
- roles/common            # system packages and user
- roles/nfs               # nfs mount for media
- roles/netbox            # netbox app (clone, venv, config, migrate, gunicorn)
- roles/redis             # local redis
- roles/nginx             # on-node nginx (HTTPS), redirects HTTP->HTTPS when http_behavior=redirect-http

Usage:
1. Customize group_vars/all.yml (use ansible-vault for secrets)
2. Place your PEM combined certificate on each node at the path defined in nginx_ssl_pem (default: /etc/ssl/netbox/netbox.pem)
3. Run: ansible-playbook -i inventory.ini site.yml -l netbox

